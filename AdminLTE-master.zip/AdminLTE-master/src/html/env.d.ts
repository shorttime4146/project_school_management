/// <reference types="astro/client" />
import '../../.astro/types.d.ts'